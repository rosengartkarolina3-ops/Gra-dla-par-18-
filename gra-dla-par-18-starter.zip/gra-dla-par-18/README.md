# Gra dla par 18+ — Namiętne Wyzwania

Gotowy **lokalny prototyp** gry mobilnej w jednym pliku `index.html`. W pełni działa w przeglądarce telefonu (bez instalowania pakietów i bez płatnych usług). To niezależna wersja robocza do repozytorium `rosengartkarolina3-ops/Gra-dla-par-18-`.

## Co działa teraz
- gra dla 4–10 osób przy jednym urządzeniu, zespoły i pary;
- 9 poziomów + Finał Główny składający się z 5 etapów;
- dwa tryby: Kobiety kontra Mężczyźni oraz Para kontra Para, z oddzielnymi punktami;
- losowanie kart bez powtórek, indywidualna akceptacja i potwierdzenie wykonania, pominięcie bez kary;
- edycja kart, w tym pięciu kart finałowych, i zapis danych w `localStorage`;
- 18+ oraz przypomnienia o dobrowolności i możliwości przerwania gry.

## Czego jeszcze nie ma

**Brak synchronizacji między telefonami, wspólnego kodu pokoju, logowania i bazy serwerowej.** Obecne dane zapisują się **wyłącznie w przeglądarce jednego urządzenia**. Udostępnienie linku każdemu telefonowi uruchomi osobną rozgrywkę, a nie wspólną sesję. To etap startowy, nie ukończona gra sieciowa.

## Wgranie do GitHub (na Androidzie)
1. Wejdź w https://github.com/rosengartkarolina3-ops/Gra-dla-par-18- i zaloguj się.
2. Otwórz `Add file` → `Upload files` (jeżeli nie widzisz tej opcji, włącz w Chrome `Wersja na komputer`).
3. Wyślij `index.html` (z folderu archiwum ZIP, jeśli korzystasz z ZIP-a).
4. Wybierz `Commit changes` na gałęzi `main`.
5. Repozytorium → `Settings` → `Pages` → `Build and deployment` → `Deploy from a branch` → `main` i `/(root)` → `Save`.
6. Po wdrożeniu link to: https://rosengartkarolina3-ops.github.io/Gra-dla-par-18-/

## Co dalej

Aby 4–10 telefonów grało jednocześnie w jednym pokoju, potrzebne będą: autoryzowane konta lub bezpieczne anonimowe sesje graczy, trwała baza serwerowa z kontrolą dostępu do pokoju, kanał aktualizacji w czasie rzeczywistym i transakcyjne przyznawanie punktów. Nie wystarczy samo GitHub Pages.
